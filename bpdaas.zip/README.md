# rds-logger
write rds logs to elasticsearch
