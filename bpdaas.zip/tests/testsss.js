var str = "2017-04-11 00:36:01.87 Server UTC adjustment: 0:00";

console.log("substring is: " + str.substring(0, 19));

console.log("log is: " + str.substring(23));